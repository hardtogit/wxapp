import mutations from './mutations'
import actions from './actions'
const Business = {
  state: {},
  mutations,
  actions
}
export default Business
