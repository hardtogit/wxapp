import * as types from '../../types'
export default {
  [types.Login] (state, data) {
    state.count += 1
  }
}
