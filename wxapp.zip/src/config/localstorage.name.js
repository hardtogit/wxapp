export default {
  wxCode: 'wxCode',
  Auth: 'Auth',
  UserInfo: 'UserInfo',
  StoreAuthToken: 'StoreAuthToken',
  PayGoodsInfo: 'PayGoodsInfo'
}
